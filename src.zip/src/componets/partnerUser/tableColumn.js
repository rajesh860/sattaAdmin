export const columns = [
  {
    title: "Name",
    dataIndex: "Name",
    key: "Name",
  },
  {
    title: "Password",
    dataIndex: "Password",
    key: "Password",
  },
  {
    title: "Phone",
    dataIndex: "Phone",
    key: "Phone",
  },
  {
    title: "CreatedBy",
    dataIndex: "CreatedBy",
    key: "CreatedBy",
  },
  {
    title: "SubscriptionMonthlyBased",
    dataIndex: "SubscriptionMonthlyBased",
    key: "SubscriptionMonthlyBased",
  },
  {
    title: "SubscriptionYearlyBased",
    dataIndex: "SubscriptionYearlyBased",
    key: "SubscriptionYearlyBased",
  },
  {
    title: "UserType",
    dataIndex: "UserType",
    key: "UserType",
  },
  {
    title: "upicid",
    dataIndex: "upicid",
    key: "upicid",
  },
  {
    title: "Action",
    dataIndex: "Action",
    key: "Action",
  },
];

export const getcolumns = [
  {
    title: "Name",
    dataIndex: "name",
    key: "name",
    //   filteredValue: [serchvalue],
    //   onFilter: (value, record) => {
    //     return (
    //       String(record.name).toLowerCase().includes(value.toLowerCase()) ||
    //       String(record.phone).toLowerCase().includes(value.toLowerCase())
    //     );
    //   },
  },
  {
    title: "phone",
    dataIndex: "phone",
    key: "phone",
  },
  {
    title: "WalletAmount",
    dataIndex: "WalletAmount",
    key: "WalletAmount",
  },
  {
    title: "Action",
    dataIndex: "Action",
    key: "Action",
  },
];
