import React from "react";

const LoginForm = () => {
  return <div>LoginForm</div>;
};

export default LoginForm;
