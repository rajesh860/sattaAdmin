export const columns = [
    {
      title: "user",
      dataIndex: "user",
      key: "user",
    },
    {
      title: "date",
      dataIndex: "date",
      key: "date",
    },
    {
      title: "time",
      dataIndex: "time",
      key: "time",
    },
    {
      title: "Amount",
      dataIndex: "Amount",
      key: "Amount",
    },
  ];