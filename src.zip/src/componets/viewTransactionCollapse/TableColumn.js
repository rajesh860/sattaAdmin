export const columns = [
  {
    title: "User",
    dataIndex: "User",
    key: "User",
  },
  {
    title: "Time",
    dataIndex: "Time",
    key: "Time",
  },
  {
    title: "Date",
    dataIndex: "Date",
    key: "Date",
  },
  {
    title: "Amount",
    dataIndex: "Amount",
    key: "Amount",
  },
  {
    title: "AccountUPI",
    dataIndex: "AccountUPI",
    key: "AccountUPI",
  },
];
