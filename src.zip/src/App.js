import AppRouter from "./AppRouter";
import "./styles/App.scss";
// import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="admin-app">
      <AppRouter />
    </div>
  );
}

export default App;
