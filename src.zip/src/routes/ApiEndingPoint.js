export const getGameData = "AdminHandling/GetGames.php";
