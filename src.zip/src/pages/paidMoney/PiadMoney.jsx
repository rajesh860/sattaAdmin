import React from "react";
import PaidMoneyComponent from "../../componets/paidMoneyComp/PaidMoneyComp";

const PiadMoneyPage = () => {
  return (
    <div>
      <h1 style={{ paddingLeft: "10px", fontSize: "22px" }}>Paid Money</h1>
      <PaidMoneyComponent />
    </div>
  );
};

export default PiadMoneyPage;
