export const number = [1, 2, 3, 4, 5, 6];
export const detail = [
  {
    number: 1,
    amount: 200,
  },
  {
    number: 2,
    amount: 200,
  },
  {
    number: 3,
    amount: 200,
  },
  {
    number: 4,
    amount: 200,
  },
  {
    number: 4,
    amount: 200,
  },
];
