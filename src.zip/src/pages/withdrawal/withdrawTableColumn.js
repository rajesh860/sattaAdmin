export const columns = [
  {
    title: "User",
    dataIndex: "User",
    key: "User",
  },
  {
    title: "Time",
    dataIndex: "Time",
    key: "Time",
  },
  {
    title: "Status",
    dataIndex: "Status",
    key: "Status",
  },
  {
    title: "Date",
    dataIndex: "Date",
    key: "Date",
  },
  {
    title: "Amount",
    dataIndex: "amount",
    key: "amount",
  },
  {
    title: "Action",
    dataIndex: "Action",
    key: "Action",
  },
];
